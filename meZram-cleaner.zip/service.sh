#!/system/bin/sh
MODDIR=${0%/*}
MODSDIR=$(dirname "$MODDIR")
MODULEDIR=/data/adb/modules/meZram-cleaner

swap=/data/swap_file
rm -rf $swap
touch $MODULEDIR/remove
